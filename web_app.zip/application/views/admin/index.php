<!-- start: Content -->
<div id="content" class="span10">

	<ul class="breadcrumb">
		<li>
			<i class="icon-home"></i>
			<a href="">الرئيسية</a>
			<i class="icon-angle-right"></i>
		</li>
		<li><a href="#">لوحة التحكم</a></li>
	</ul>

	<div class="row-fluid">

		<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
			<!-- <div class="boxchart">5,6,7,2,0,4,2,4,8,2,3,3,2</div> -->
			<div class="number"> 854 <i class="icon-arrow-up"></i></div>
			<div class="title">عقار</div>
			<div class="footer">
				<a href="#"> مشاهدة التقرير </a>
			</div>
		</div>

    <div class="span3 statbox green" onTablet="span6" onDesktop="span3">
			<!-- <div class="boxchart">5,6,7,2,0,4,2,4,8,2,3,3,2</div> -->
			<div class="number"> 3K <i class="icon-arrow-up"></i></div>
			<div class="title">مستخدم</div>
			<div class="footer">
				<a href="#"> مشاهدة التقرير </a>
			</div>
		</div>

		<div class="span3 statbox blue" onTablet="span6" onDesktop="span3">
			<!-- <div class="boxchart">1,2,6,4,0,8,2,4,5,3,1,7,5</div> -->
			<div class="number">123 <i class="icon-arrow-up"></i></div>
			<div class="title">مشاهدة</div>
			<div class="footer">
				<a href="#"> </a>
			</div>
		</div>


		<!-- <div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
			<div class="boxchart">5,6,7,2,0,-4,-2,4,8,2,3,3,2</div>
			<div class="number">982<i class="icon-arrow-up"></i></div>
			<div class="title">orders</div>
			<div class="footer">
				<a href="#"> read full report</a>
			</div>
		</div> -->

		<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
			<!-- <div class="boxchart">7,2,2,2,1,-4,-2,4,8,,0,3,3,5</div> -->
			<div class="number">678 <i class="icon-arrow-down"></i></div>
			<div class="title">مبيعات</div>
			<div class="footer">
				<a href="#"> مشاهدة التقرير</a>
			</div>
		</div>

	</div>

    <div class="row-fluid">
      <div class="box-content">
        <table dir="rtl" class="table table-bordered table-striped table-condensed">
            <thead dir="rtl">
              <tr>
                <th dir="rtl">Username</th>
                <th>Date registered</th>
                <th>Role</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Dennis Ji</td>
                <td class="center">2012/01/01</td>
                <td class="center">Member</td>
                <td class="center">
                  <span class="label label-success">Active</span>
                </td>
              </tr>
              <tr>
                <td>Dennis Ji</td>
                <td class="center">2012/02/01</td>
                <td class="center">Staff</td>
                <td class="center">
                  <span class="label label-important">Banned</span>
                </td>
              </tr>
              <tr>
                <td>Dennis Ji</td>
                <td class="center">2012/02/01</td>
                <td class="center">Admin</td>
                <td class="center">
                  <span class="label">Inactive</span>
                </td>
              </tr>
              <tr>
                <td>Dennis Ji</td>
                <td class="center">2012/03/01</td>
                <td class="center">Member</td>
                <td class="center">
                  <span class="label label-warning">Pending</span>
                </td>
              </tr>
              <tr>
                <td>Dennis Ji</td>
                <td class="center">2012/01/21</td>
                <td class="center">Staff</td>
                <td class="center">
                  <span class="label label-success">Active</span>
                </td>
              </tr>
            </tbody>
         </table>

        <div class="pagination pagination-centered">
          <ul>
            <li><a href="#">Prev</a></li>
            <li class="active">
              <a href="#">1</a>
            </li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li><a href="#">4</a></li>
            <li><a href="#">Next</a></li>
          </ul>
        </div>

      </div>
    </div>

</div>
