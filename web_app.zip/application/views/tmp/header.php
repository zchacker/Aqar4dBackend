<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <!-- here idea for css cashing  -->
    <!-- https://css-tricks.com/can-we-prevent-css-caching/ -->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?=base_url()?>css/boot4/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url()?>fontawesome/css/all.css">
    <link rel="stylesheet" href="<?=base_url()?>css/main-style.css?<?php echo date('l jS \of F Y h:i:s A'); ?>">

    <script src="<?=base_url()?>js/boot4/jquery.min.js" charset="utf-8"></script>
    <script src="<?=base_url()?>js/boot4/bootstrap.js" charset="utf-8"></script>
    <title>الصفحة الرئيسية</title>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row d-none d-md-block d-lg-block">
        <header>
          <div class="col-md-2">
            <div class="logo">
              <img class="logo" src="<?=base_url()?>img/logo.jpg" alt="logo" width="120">
            </div>
          </div>
          <div class="col-md-7">
            <nav>
              <ul class="nav_links">
                <li><a href="#">الرئيسية</a></li>
                <li><a href="#">العقارات</a></li>
                <li><a href="#">عن الموقع</a></li>
              </ul>
            </nav>
          </div>
          <div class="col-md-3">
            <a href="<?=base_url()?>client/add_entity" class="btn btn-primary">اضف عقار</a>
            <a href="<?=base_url()?>client/register" class="btn btn-warning">تسجيل</a>
            <a href="<?=base_url()?>client/login" class="btn btn-success">دخول</a>
          </div>
        </header>
      </div>


      <div class="row d-none  d-block d-sm-block d-md-none d-lg-none d-xl-none">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <a class="navbar-brand" href="#">Navbar</a>

          <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
              <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled" href="#">Disabled</a>
              </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
          </div>
        </nav>
      </div>
