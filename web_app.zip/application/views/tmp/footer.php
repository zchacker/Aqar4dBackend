
		<script src="<?=base_url()?>js/boot4/jquery.min.js" charset="utf-8"></script>
    </div>
    <footer>
    	
    </footer>
  </body>
</html>
