<!-- main content of documnet -->
<div class="row">
  <div class="register_form">
    <h2>الاشتراك بالموقع</h2>
    <?=@$msg?>
    <!-- https://twitter.com/larraa2019/status/1183109555275874305 -->
    <form class="" action="" method="post">
      <div class="form-row">
        <label for="name">الاسم</label>
        <input type="text" class="form-control" id="name" name="name" value="">
      </div>

      <div class="form-row">
        <label for="phone">رقم الهاتف</label>
        <input type="tel" class="form-control" id="phone" name="phone" value="">
      </div>

      <div class="form-row">
        <label for="email">البريد الالكتروني</label>
        <input type="email" class="form-control" id="email" name="email" value="" autocomplete="no" />
      </div>

      <div class="form-row">
        <label for="pass1">كلمة المرور</label>
        <input type="password" class="form-control" id="pass1" name="pass1" value="" autocomplete="no" />
      </div>

      <div class="form-row">
        <label for="pass2">تأكيد كلمة المرور</label>
        <input type="password" class="form-control" id="pass2" name="pass2" value="">
      </div>

      <div class="form-row">
        <button type="submit" class="btn btn-success btn-block" name="button">الاشتراك بالموقع</button>
      </div>


      <div class="form-row">
        <a href="<?=base_url()?>client/login" class="btn btn-warning btn-block" >تسجل الدخول إلى حسابك</a>
      </div>

    </form>
  </div>
</div>
