<section class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="page_title">
        <div class="title">
          <h3>عقاراتك</h3>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="entity_card">
          <a href="javascript:void(0)"><p>فيلا للبيع في شارع انطاكية ، حي اشبيلية ، الرياض</p></a>
          <img src="<?=base_url();?>img/real_estate/demo.jpg" alt="">
        </div>
      </div>

      <div class="col-md-4">
        <div class="entity_card">
          <a href="javascript:void(0)"><p>فيلا للبيع في شارع انطاكية ، حي اشبيلية ، الرياض</p></a>
          <img src="<?=base_url();?>img/real_estate/demo.jpg" alt="">
        </div>
      </div>

      <div class="col-md-4">
        <div class="entity_card">
          <a href="javascript:void(0)"><p>فيلا للبيع في شارع انطاكية ، حي اشبيلية ، الرياض</p></a>
          <img src="<?=base_url();?>img/real_estate/demo.jpg" alt="">
        </div>
      </div>

      <div class="col-md-4">
        <div class="entity_card">
          <a href="javascript:void(0)"><p>فيلا للبيع في شارع انطاكية ، حي اشبيلية ، الرياض</p></a>
          <img src="<?=base_url();?>img/real_estate/demo.jpg" alt="">
        </div>
      </div>

      <div class="col-md-4">
        <div class="entity_card">
          <a href="javascript:void(0)"><p>فيلا للبيع في شارع انطاكية ، حي اشبيلية ، الرياض</p></a>
          <img src="<?=base_url();?>img/real_estate/demo.jpg" alt="">
        </div>
      </div>

    </div>
  </div>
</section>
