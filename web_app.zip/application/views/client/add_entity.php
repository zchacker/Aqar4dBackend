<div class="row">
  <div class="col-md-12">
    <section class="page_content">
      <div class="add_entity_form">
        <?=$error_msg?>
        <h2>إضافة عقار جديد</h2>
        <form class="" action="" method="post" enctype="multipart/form-data">
          <div class="form-row ">
            <label for="title">العنوان</label>
            <input type="text" class="form-control" name="title" id="title" value="">
          </div>

          <div class="form-row">
            <label for="price">السعر</label>
            <input type="text" class="form-control" name="price" id="price" value="">
          </div>

          <div class="form-row">
            <label for="city">المدينة</label>
            <input type="text" class="form-control" name="city" id="city" value="">
          </div>

          <div class="form-row">
            <label for="country">الدولة</label>
            <input type="text" class="form-control" name="country" id="country" value="">
          </div>

          <div class="form-row">
            <label for="phone">رقم الهاتف</label>
            <input type="text" class="form-control" name="phone" id="phone" value="">
          </div>

          <div class="form-row">
            <label for="email">البريد الالكتروني</label>
            <input type="text" class="form-control" name="email" id="email" value="">
          </div>

          <div class="form-row">
            <label for="images">صور للعقار <span>*حتى 29 صورة</span></label>
            <input type="file" class="form-control" name="images[]" multiple id="images" value="" accept="image/x-png,image/jpeg,">
          </div>

          <div class="form-row">
            <label for="images">فديو ان وجد <span>mp4 فقط</span></label>
            <input type="file" class="form-control" name="video" id="images" value="" accept="video/mp4,video/x-m4">
          </div>


          <div class="form-row">
            <label for="type">نوع الاعلان</label>
            <select id="type" name="type" class="form-control" >
              <option  value="1">بيع</option>
              <option value="2">شراء</option>
              <option value="3">إيجار</option>
            </select>
          </div>

          <div class="form-row">
            <label for="description">وصف للعقار</label>
            <textarea name="description" id="description" class="form-control" rows="8" cols="80"></textarea>
          </div>

          <input type="hidden" name="lat" id="lat" value="24.459145802677078">
          <input type="hidden" name="lng" id="lng" value="39.66354448280333">

          <div class="form-row">
            <div id="map"></div>
          </div>

          <div class="form-row">
            <button type="submit" name="button" class="btn btn-success btn-block">إضافة</button>
          </div>

        </form>
      </div>

    </section>
  </div>
</div>

<script>
    // Initialize and add the map
    function initMap() {
      // The location of Uluru
      var markerLocation = {lat: 24.459145802677078 , lng: 39.66354448280333};
      // The map, centered at Uluru
      var map = new google.maps.Map(document.getElementById('map'), {zoom: 8, center: markerLocation});
      // The marker, positioned at Uluru
      var marker = new google.maps.Marker({
          position: markerLocation,
          map: map,
          draggable: true
       });

       marker.addListener('dragend', function() {
         // map.setZoom(8);
         // map.setCenter(marker.getPosition());

         var x = marker.getPosition().lat();
         var y = marker.getPosition().lng();

         document.getElementById("location_x").value = x;
         document.getElementById("location_y").value = y;
       });

    }
</script>

<script async defer
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBovYrdTvtypEFdtSqn3EwtJx-9CvWeBqk&callback=initMap">
</script>
