<section class="page_content">

<div class="messages_wrap">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <h3>الرسائل</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div class="users_list_wrap">
          <ul class="users_list">
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>
            <a href="javascript:void()"><li>أحمد احمد</li></a>

          </ul>
        </div>
      </div>
      <div class="col-md-8">
        <div class="chat">

            <div class="mine messages">
              <div class="message last">
                Dude
               </div>
            </div>

            <div class="yours messages">
              <div class="message">
                Hey!
              </div>
              <div class="message">
                You there?
              </div>
              <div class="message last">
                Hello, how's it going?
              </div>
            </div>

            <div class="mine messages">
              <div class="message">
                Great thanks!
              </div>
              <div class="message last">
                <span>كيف الحال</span>
               </div>
            </div>

            <div class="mine messages">
              <div class="message">
                Great thanks!
              </div>
              <div class="message last">
                <span>كيف الحال</span>
               </div>
            </div>

            <div class="mine messages">
              <div class="message">
                Great thanks!
              </div>
              <div class="message last">
                <span>كيف الحال</span>
               </div>
            </div>

            <div class="mine messages">
              <div class="message">
                Great thanks!
              </div>
              <div class="message last">
                <span>كيف الحال</span>
               </div>
            </div>


            <div class="yours messages">
              <div class="message">
                  <span>الحمدلله</span>
              </div>
              <div class="message">
                  <span>الحمدلله</span>
              </div>
            </div>

        </div>
      </div>
    </div>
  </div>
</div>

</section>
