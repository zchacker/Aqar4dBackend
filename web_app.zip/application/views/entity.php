<section class="">
  <div class="container">
  <!-- <div class="row">
    <div class="col-md-12">
      <div class="page_title">
        <div class="title">
          <h3>عقاراتك</h3>
        </div>
      </div>
    </div>
  </div> -->

    <div class="row">
      <div class="col-md-12">
        <h2><?=$real_estate->title?></h2>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
        <div id="slider" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <ul class="carousel-indicators">
            <?php
              $real_estate_media = $this->client_model->get_photos_for_real_estate($real_estate->id)->result();
              $i = 0;
              foreach ($real_estate_media as $key => $value) {
                if($i == 0)
                  echo '<li data-target="#slider" data-slide-to="'.$i.'" class="active"></li>';
                else
                  echo '<li data-target="#slider" data-slide-to="'.$i.'" ></li>';

                  $i++;
              }
            ?>
          </ul>

          <!-- The slideshow -->
          <div class="carousel-inner">
            <?php
              $i = 0;
              foreach ($real_estate_media as $key => $value) {
                $img = base_url().'uploads/'.$value->media_path;
                echo '<br/>';
                if($i == 0){
                  echo '<div class="carousel-item active">
                    <img src="'.$img.'" alt="" >
                  </div>';
                }else{
                  echo '<div class="carousel-item ">
                    <img src="'.$img.'" alt="" >
                  </div>';
                }

                $i++;
              }
            ?>
          </div>

          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#slider" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#slider" data-slide="next">
            <span class="carousel-control-next-icon"></span>
          </a>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4">
         <span>نوع العقار </span>      
         <span><?=$type_string?></span>
      </div>
      <div class="col-md-4">
        
      </div>
      <div class="col-md-4">
        
      </div>
    </div>

    <div class="row">

      <div class="col-md-12">
        <p><?=$real_estate->description?></p>
      </div>
    </div>


  </div>
</section>

<script src="<?=base_url()?>js/boot4/jquery.min.js" charset="utf-8"></script>
<script src="<?=base_url()?>js/boot4/popper.min.js" charset="utf-8"></script>
<script src="<?=base_url()?>js/boot4/bootstrap.js" charset="utf-8"></script>
