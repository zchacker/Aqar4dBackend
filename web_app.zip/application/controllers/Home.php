<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller{

  //this page is not require a login to show it
  // this contoller to show all data for all users without requier to login

  public function __construct(){
    parent::__construct();
    $this->load->model("login_model");
    $this->load->model("client_model");

    // $this->load->library('session');
  }

  // this is main page of website
  public function index($page = 1){

    $data['results'] = $this->client_model->get_entity_estates()->result();
    $this->load->view("tmp/header" , $data);
    $this->load->view("index" , $data);
    $this->load->view("tmp/footer" , $data);

  }

  public function entities(){
    $this->load->view('tmp/header');
    $this->load->view('client/show_entities');
    $this->load->view('tmp/footer');
  }

  public function entity($id){

    $real_estate_data = $this->client_model->get_real_estate_data($id);
    $rows = $real_estate_data->num_rows();



    if($rows == 1){
      $data['real_estate'] = $real_estate_data->result()[0];

      $type = $data['real_estate']->type;
      $type_string = "";
      if($type == 1){
        $type_string = 'بيع';
      }elseif($type == 2){
        $type_string = 'شراء';
      }elseif($type == 3){
        $type_string = 'إيجار';
      }

      $data['type_string'] = $type_string;

      $this->load->view('tmp/header' , $data);
      $this->load->view('entity');
      $this->load->view('tmp/footer');

    }else{
      echo 'الرابط خطأ';
    }

  }

  public function real_estate($id){

  }

}

?>
