<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller{

  //this page is not require a login to show it

  public function __construct(){
    parent::__construct();
    $this->load->model("login_model");
    // $this->load->library('session');
  }

  public function index(){
    $this->load->view("admin/tmp/header");
    $this->load->view("admin/index");
    $this->load->view("admin/tmp/footer");
  }

}

?>
