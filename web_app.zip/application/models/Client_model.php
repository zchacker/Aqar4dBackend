<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_model extends CI_Model {

  public function add_entity_estate($data){
    return $this->db->insert('real_estate' , $data);
  }

  public function edit_entity_estate($data , $id){
    $this->db->where('id' , $id);
    return $this->db->update('real_estate' , $data);
  }

  public function delete_enetity($id){
    $this->db->where('id' , $id);
    return $this->db->delete('real_estate');
  }

  public function add_file_data($data){
    return $this->db->insert('media' , $data);
  }

  public function get_entity_estates(){
    return $this->db->get('real_estate');
  }

  public function get_photo($real_estate_id){
    $this->db->where('for_real_estate' , $real_estate_id);
    $this->db->where('type' , 1);
    return $this->db->get('media');
  }

  public function get_real_estate_data($id){
    $this->db->where('id' , $id);
    return $this->db->get('real_estate');
  }

  public function get_photos_for_real_estate($real_estate_id){
    $this->db->where('type' , 1);
    $this->db->where('for_real_estate' , $real_estate_id);
    return $this->db->get('media');
  }

}

?>
