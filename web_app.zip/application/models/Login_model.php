<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

  public function add_user($data){

    // check if the email was in database or not
    $this->db->where('email' , $data['email']);
    $result = $this->db->get('user');
    $rows = $result->num_rows();

    if($rows == 0){// rows is 0
      $this->db->insert('user' , $data);
      return true;
    }else{
      return false;
    }

  }


}

?>
